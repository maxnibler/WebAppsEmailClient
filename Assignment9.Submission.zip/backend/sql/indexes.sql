-- Index Your Tables Here --
CREATE INDEX mailbox_idx ON mail(mailbox);